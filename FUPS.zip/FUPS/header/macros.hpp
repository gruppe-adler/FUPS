#define selectRandom(X) ((X) select floor random count (X))
#define sideIndex(X) (FUPS_sideOrder find side X)