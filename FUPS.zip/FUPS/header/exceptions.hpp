#define ILLEGALARGUMENTSEXCEPTION "Illegal arguments"
#define NOSUCHMARKEREXCEPTION(X) ("No such marker: " + X)
#define INDEXOUTOFBOUNDEXCEPTION "Index out of bound"
#define NULLPOINTEREXCEPTION "Nullpointer"
#define STRUCTUREMISMATCHEXCEPTION "Type mismatch in struct setter"