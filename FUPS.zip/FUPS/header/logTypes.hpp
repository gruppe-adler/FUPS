#define ERROR_LOG		0
#define ENVIROMENT_LOG	1
#define ACTIONS_LOG		2
#define STATS_LOG		3