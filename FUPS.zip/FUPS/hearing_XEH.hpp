class Extended_Fired_Eventhandlers {
	class AllVehicles {
		fups_audio_fired = "_this call FUPS_fnc_hearing_eh;";
	};
};
